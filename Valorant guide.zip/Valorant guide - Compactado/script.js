const container = document.getElementById('container');
const registerBtn = document.getElementById('register');
const loginBtn = document.getElementById('login');

registerBtn.addEventListener('click', () => {
    container.classList.add("active");
    let text = document.querySelector('h1')
    text.innerHTML= 'welcome!'
});

loginBtn.addEventListener('click', () => {
    container.classList.remove("active");
    let text = document.querySelector('h1')
    text.innerHTML= 'welcome back!'
});